package model;

public class AppAdmin extends User{

    public AppAdmin(String username, String password) {
        super(username, password);
    }

}
