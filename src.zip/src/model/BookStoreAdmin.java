package model;

public class BookStoreAdmin extends User{

    public BookStoreAdmin(String username, String password) {
        super(username, password);
    }

}
