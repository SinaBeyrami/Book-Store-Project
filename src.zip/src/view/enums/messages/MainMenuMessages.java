package view.enums.messages;

public enum MainMenuMessages {
    INVALID_MENU,
    SUCCESS_CUSTOMER,
    SUCCESS_BOOKSTORE_ADMIN,
    SUCCESS_APP_ADMIN,
    ACCESS_DENIED,
}
