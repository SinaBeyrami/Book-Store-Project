package view.enums.messages;

public enum AppAdminMenuMessages {

    USERNAME_EXISTS,
    INVALID_USERNAME,
    INVALID_PASSWORD,
    WEAK_PASSWORD,
    SUCCESS,
    INVALID_TYPE,
    NAME_NOT_FOUND,
    USERNAME_NOT_EXISTS,
    INVALID_AMOUNT,
    INVALID_CODE,

}
