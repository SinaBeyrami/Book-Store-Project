import model.AppAdmin;
import view.LoginMenu;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String snapfoodAdminUsername = scanner.next().trim();
        scanner.nextLine();
        String snapfoodAdminPassword = scanner.next().trim();
        scanner.nextLine();
        AppAdmin appAdmin = new AppAdmin(snapfoodAdminUsername , snapfoodAdminPassword);
        LoginMenu.run(scanner);
    }

}
